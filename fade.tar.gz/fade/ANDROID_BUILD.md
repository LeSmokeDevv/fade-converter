# Building FADE CONVERTER for Android

This is a Qt 6 / CMake Android app. Build it with Qt Creator and a Qt for Android kit; the Android Gradle folder in this source is a template, not a standalone native Android project.

## Required tools

- Qt 6 installed with the Android kit for `arm64-v8a` (add `x86_64` only if you need an emulator build).
- Qt Creator with CMake and Ninja support.
- Android SDK platform-tools, an Android platform/build-tools version supported by the selected Qt release, and the matching Android NDK.
- A JDK version supported by that Qt release. Let Qt Creator's Android setup page select or validate the SDK, NDK, and JDK versions together.

## Build in Qt Creator

1. Open `CMakeLists.txt` in Qt Creator.
2. Configure the project with the installed Qt 6 Android kit for `arm64-v8a`.
3. In **Preferences/Options → Devices → Android**, configure the SDK, NDK, and JDK paths and run the setup checks.
4. Build the project, then use Qt Creator's Android deploy/build action to create and install a debug APK on a connected device.
5. For a release APK or Play Store bundle, configure a signing key in Qt Creator's Android deployment settings. Keep the private signing key outside this source archive.

The Android launcher label is set to **FADE CONVERTER**. The existing application ID `lilmuff1.xcoder` is intentionally preserved so a future signed build can retain the same Android package identity.
