#ifndef UI_ANIMATIONS_H
#define UI_ANIMATIONS_H

#include <QAbstractAnimation>
#include <QEvent>
#include <QEasingCurve>
#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>
#include <QSequentialAnimationGroup>
#include <QWidget>
#include <initializer_list>

namespace UiAnimations {

inline QGraphicsOpacityEffect *opacityEffect(QWidget *widget)
{
    auto *effect = new QGraphicsOpacityEffect(widget);
    effect->setOpacity(1.0);
    widget->setGraphicsEffect(effect);
    return effect;
}

inline void fadeIn(QWidget *widget, QWidget *owner, int duration = 360)
{
    auto *effect = opacityEffect(widget);
    effect->setOpacity(0.0);
    auto *animation = new QPropertyAnimation(effect, "opacity", owner);
    animation->setDuration(duration);
    animation->setStartValue(0.0);
    animation->setEndValue(1.0);
    animation->setEasingCurve(QEasingCurve::OutCubic);
    animation->start(QAbstractAnimation::DeleteWhenStopped);
}

inline void fadeInSequence(std::initializer_list<QWidget *> widgets, QWidget *owner)
{
    auto *group = new QSequentialAnimationGroup(owner);
    for (QWidget *widget : widgets) {
        auto *effect = opacityEffect(widget);
        effect->setOpacity(0.0);
        group->addPause(70);
        auto *animation = new QPropertyAnimation(effect, "opacity", group);
        animation->setDuration(360);
        animation->setStartValue(0.0);
        animation->setEndValue(1.0);
        animation->setEasingCurve(QEasingCurve::OutCubic);
        group->addAnimation(animation);
    }
    group->start(QAbstractAnimation::DeleteWhenStopped);
}

class HoverOpacity final : public QObject
{
public:
    explicit HoverOpacity(QWidget *target)
        : QObject(target), target_(target), effect_(opacityEffect(target)),
          animation_(new QPropertyAnimation(effect_, "opacity", this))
    {
        target_->installEventFilter(this);
        animation_->setDuration(170);
        animation_->setEasingCurve(QEasingCurve::OutCubic);
    }

protected:
    bool eventFilter(QObject *watched, QEvent *event) override
    {
        if (watched == target_ && (event->type() == QEvent::Enter || event->type() == QEvent::Leave)) {
            animation_->stop();
            animation_->setStartValue(effect_->opacity());
            animation_->setEndValue(event->type() == QEvent::Enter ? 0.88 : 1.0);
            animation_->start();
        }
        return QObject::eventFilter(watched, event);
    }

private:
    QWidget *target_;
    QGraphicsOpacityEffect *effect_;
    QPropertyAnimation *animation_;
};

} // namespace UiAnimations

#endif // UI_ANIMATIONS_H
